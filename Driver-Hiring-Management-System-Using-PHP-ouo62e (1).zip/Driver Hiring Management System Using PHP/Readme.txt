How to run the Driver Hiring Management Project using PHP and MySQL

1. Download the project zip file

2. Extract the file and copy dhms folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/Html)

4.Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with the name  dhmsdb

6. Import dhmsdb.sql file(given inside the zip package in SQL file folder)

7. Run the script http://localhost/dhms

Admin Credential
Username: admin@gmail.com
Password: Test@123

Credential for User panel :

Username: anuj@gmail.com
Password: Test@123

Or Register a new user.

Credential for Driver panel :

Username: raju@gmail.com
Password: Test@123

Or Register a new Driver.